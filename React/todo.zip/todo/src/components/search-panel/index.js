import AppSearchPanel from "./search-panel";

export default AppSearchPanel;
