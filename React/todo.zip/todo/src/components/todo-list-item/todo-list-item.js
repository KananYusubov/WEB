import React from "react";
import "./todo-list-item.css";

class TodoListItem extends React.Component {
  state = {
    done: false,
    important: false,
  };

  onLabelClick = () => {
    this.setState(({ done }) => {
      return { done: !done };
    });
  };

  onMarkImportant = () => {
    this.setState(({ important }) => {
      return { important: !important };
    });
  };

  render() {
    const { text, onDeleted } = this.props;
    const { done, important } = this.state;
    let classNames = "todo-list-item ";
    let btnClassNames = "btn btn-outline-success btn-sm float-right";

    if (done) {
      classNames += " done ";
    }

    if (!done && important) {
      classNames += " important ";
      btnClassNames += " bg-green ";
    }

    return (
      <span className={classNames}>
        <span className="todo-list-item-label " onClick={this.onLabelClick}>
          {text}
        </span>

        <button
          className={btnClassNames}
          onClick={this.onMarkImportant}
          type={"button"}
        >
          <i className={"fa fa-exclamation"} />
        </button>

        <button
          className={"btn btn-outline-danger btn-sm float-right"}
          onClick={onDeleted}
          type={"button"}
        >
          <i className={"fa fa-trash-o"} />
        </button>
      </span>
    );
  }
}

export default TodoListItem;
